package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements ListFragment.onItemSelectedListener, GridFragment.OnItemSelectedListener {
    private ListFragment listFragment = new ListFragment();
    private GridFragment gridFragment = new GridFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.layout_for_fun);
//        Button funButton = findViewById(R.id.button_for_fun);
//        final TextView awesomeTextView = findViewById(R.id.awesome_text_view);
//        funButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                awesomeTextView.setText("Jackson!");
//            }
//        });
        setContentView(R.layout.activity_main);
//        ListView eventListView = (ListView) findViewById(R.id.event_list);
//        EventAdapter eventAdapter = new EventAdapter(this, DataService.getEventData());
//        eventListView.setAdapter(eventAdapter);
        if (getSupportFragmentManager().findFragmentById(R.id.list_container) == null) {
            getSupportFragmentManager().beginTransaction().add(R.id.list_container, listFragment).commit();
        }
        if (getSupportFragmentManager().findFragmentById(R.id.grid_container) == null) {
            getSupportFragmentManager().beginTransaction().add(R.id.grid_container, gridFragment).commit();
        }
    }
    private boolean isTablet() {
        return (getApplicationContext().getResources().getConfiguration().screenLayout &
                Configuration.SCREENLAYOUT_SIZE_MASK) >=
                Configuration.SCREENLAYOUT_SIZE_LARGE;
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("Life cycel test", "we are onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("Life cycle test", "we are onResume()");

    }

    @Override
    protected void onPause() {

        super.onPause();
        Log.e("Life cycle test", "we are onPause()");
    }

    @Override
    protected void onStop() {

        super.onStop();
        Log.e("Life cycle test", "we are onStop()");
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
        Log.e("Life cycle test", "We are at onDestroy()");
    }

    @Override
    public void onItemSelected(int position) {
        gridFragment.onItemSelected(position);
    }

    @Override
    public void onElementSelected(int position) {
        listFragment.onElementSelected(position);
    }
}
